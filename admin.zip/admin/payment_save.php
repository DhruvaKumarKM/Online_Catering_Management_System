<?php 

include('../includes/dbcon.php');
	
	$id = $_POST['id'];
	$amount = $_POST['amount'];
	$status = $_POST['status'];
	
	$date=date("Y-m-d");
	if ($amount<>0)
	{
		mysqli_query($con,"INSERT INTO payment(amount,rid,payment_date) 
			VALUES('$amount','$id','$date')")or die(mysqli_error());  
	}
		

		mysqli_query($con,"UPDATE reservation SET balance=balance-'$amount',r_status='$status' where rid='$id'")or die(mysqli_error($con)); 

			echo "<script type='text/javascript'>alert('Successfully added new payment!');</script>";
			echo "<script>document.location='pending.php'</script>";   
	
	
?>