<div id="reserve" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
	<div class="modal-dialog">
	  <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
          <h4 class="modal-title center"><i class = "fa fa-key"></i>Select Year</h4>
        </div>
         <div class="modal-body">
             <div class="padd">
                  <!-- Login form -->
                  <form class="form-horizontal" method="post" action="reservation_report.php">	
          
					         <div class="form-group">
                      <label class="control-label col-lg-3" for="inputPassword">Year</label>
                      <div class="col-lg-7">
            						<select name ="year1" class = "form-control">					
            							<option>2017</option>							
            							<option>2018</option>							
            							<option>2019</option>							
            							<option>2020</option>							
            						</select>
                      </div>
                    </div>
					          <div class="col-md-3">
                  </div>  
                  <div class="col-md-7">
                    <button type="submit" class="btn btn-primary pull-right">Display</button> 
                  </div><br>
                  </form>
				  
				      </div>
          </div>
        <div class="modal-footer"> 
        </div>        
		</div>
    </div>
</div>




