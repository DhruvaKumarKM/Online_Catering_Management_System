<!-- Header starts -->
  <header>
    <div class="container">
      <div class="row">
        <!-- Logo section -->
        <div class="col-md-4">
          <!-- Logo. -->
          <div class="logo">
           <a href="index.php"> <h2 class = "logo-text"><img src = "../img/cc.png">Chimney<span class="bold">Catering</span></h2></a>	
           
          </div>
          <!-- Logo ends -->
        </div>
        <!-- Button section -->
      
        <!-- Data section -->
		</div>
		</div>
	
    
  </header>
  